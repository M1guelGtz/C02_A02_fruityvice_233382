import { ListFruits } from "../models/ListFruits.js";
export const listFruits = new ListFruits()